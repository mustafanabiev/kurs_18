package com.example.firebase_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
